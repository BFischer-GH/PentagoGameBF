# Pentago protocol

This repository contains the documentation for the protocol used to communicate between clients and servers for Pentago. 

For a description of the mandatory set of commands, see [commands.md](commands.md). An example of a game execution can be found in [example_game.md](example_game.md) 

Possible extensions can be found in the extensions-subdirectory. 